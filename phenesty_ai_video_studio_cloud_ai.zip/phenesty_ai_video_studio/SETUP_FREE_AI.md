# Connect hosted AI video generation (free-only setup)

This update replaces the animated prompt-card generator with a request to a hosted text-to-video model. Your 8 GB laptop only runs the website; the model runs in the cloud.

## Important free-use limitation

Hugging Face documents a small monthly allowance for Inference Providers for free accounts (currently listed as US$0.10, subject to change). That may be insufficient for video generation, and access depends on the provider/model. This project does not add a payment method, purchase credits, or deliberately fall back to a fake video. If free credits or model access are unavailable, generation will fail with a visible message. Do not add payment details or buy credits if your budget is zero.

## One-time setup on Windows

1. Open https://huggingface.co/ and create a free account or sign in.
2. Open https://huggingface.co/settings/tokens and create a token with the permission needed for Inference Providers / inference. Treat it like a password.
3. Stop the currently running website: go to the black Command Prompt window and press `Ctrl+C`.
4. Open the folder where you extracted Phenesty AI Video Studio.
5. Copy `.env.example` and name the copy `.env` (make sure it is not named `.env.txt`). You can use File Explorer's **View → Show → File name extensions** to check.
6. Open `.env` in Notepad. Replace `hf_paste_your_token_here` with your actual token, leaving `HF_TOKEN=` at the beginning. Do not add quotes. Save and close Notepad.
7. Double-click `START_VIDEO_STUDIO.bat`. It will install the new Python packages and start the website.
8. Open or refresh http://127.0.0.1:5000 in Chrome.
9. Enter a prompt such as `A lion walking across the African savannah at golden sunset, natural wildlife movement, cinematic camera, no words or captions` and click **Generate AI video**. Wait for the hosted provider to respond; the first request may take a while.

## If it fails

- **Token/permission error:** create a new token with inference permissions and replace the token in `.env`.
- **Credits/billing/quota error:** stop here; do not add a payment method or buy credits. Free hosted video generation may not be available to your account at that time.
- **Model/provider error:** the selected hosted model may be unavailable or unsupported for your account. The app intentionally shows an error instead of silently producing a fake title card.
- **Do not share your token** in screenshots, chat, GitHub, or public repositories. If it leaks, revoke it immediately in Hugging Face settings.

## What changed

- The current design and prompt workflow are preserved.
- Video generation now requests a hosted AI text-to-video model.
- The app never substitutes the old text-card demo when cloud generation fails.
- Video preview and MP4 download use separate routes.
- The server remains bound to `127.0.0.1`, so this is a local website, not yet a public multi-user deployment.
