@echo off
title Phenesty AI Video Studio
cd /d "%~dp0"

echo ============================================
echo   PHENESTY AI VIDEO STUDIO - STARTUP
echo ============================================
echo.

where py >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python was not found.
  echo Install Python 3.10 or newer from https://www.python.org/downloads/
  echo During installation, tick "Add Python to PATH".
  echo.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Setting up the Python environment for the first time...
  py -m venv .venv
  if errorlevel 1 (
    echo ERROR: Could not create the Python environment.
    echo.
    pause
    exit /b 1
  )
)

echo Installing/checking required packages. This may take a few minutes...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 (
  echo WARNING: pip upgrade failed. Continuing to install project packages...
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo ERROR: Package installation failed. Check your internet connection
  echo and the error above, then try running this file again.
  echo.
  pause
  exit /b 1
)

echo.
echo Starting Phenesty AI Video Studio...
echo When you see the local address below, open Chrome and visit:
echo http://127.0.0.1:5000
echo.
echo Keep this window open while using the website.
echo To stop the server, press Ctrl+C in this window.
echo.
".venv\Scripts\python.exe" app.py
echo.
echo The server has stopped. If an error appeared above, take a screenshot
echo or copy the error message so it can be fixed.
echo.
pause
